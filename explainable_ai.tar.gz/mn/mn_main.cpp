//----------------------------------------------------------------------

#include <iostream>

#include "mn_main.hpp"
#include "mn_train_t.hpp"
#include "su_begin_end_t.hpp"

//----------------------------------------------------------------------

using namespace std;
using namespace mn;
using namespace su;

//----------------------------------------------------------------------

bool
mn::mn_main ()
{
    su_begin_end_t begin_end (__FILE__, __LINE__, "mn_main");

    // Open file that houses the labels of the training set

    if (!mn_train_t::read_label_file ())
    {
        return (false);
    }

    return (true);
}

//----------------------------------------------------------------------

