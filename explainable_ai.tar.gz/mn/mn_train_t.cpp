//----------------------------------------------------------------------

#include <iostream>
#include <fstream>

#include "mn_train_t.hpp"

//----------------------------------------------------------------------

using namespace mn;
using namespace std;

//----------------------------------------------------------------------

const string
mn_train_t::get_label_fn ()
{
    return ("train-labels-idx1-ubyte");
}

//----------------------------------------------------------------------

bool
mn_train_t::read_label_file ()
{
    // Open label file

    ifstream label_file (get_label_fn ());

    if (!label_file.is_open ())
    {
        cout << "ERROR:: " << get_label_fn () << " does not exist or "
             << "is unreadable" << endl;
        return (false);
    }

    return (true);
}

//----------------------------------------------------------------------
