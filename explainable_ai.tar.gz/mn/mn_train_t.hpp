//----------------------------------------------------------------------

#ifndef INCLUDED_mn_train_t_hpp
#define INCLUDED_mn_train_t_hpp

//----------------------------------------------------------------------

#include <string>

//----------------------------------------------------------------------

namespace mn
{

//----------------------------------------------------------------------

class mn_train_t
{

public:
    
    /**
        \par RETURN VALUE
        The name of the disk file that houses the labels of the training
        data set
    */

    static const std::string
    get_label_fn ();

    /**
        \par RETURN VALUE
        true => success, false => failure
    */

    static bool
    read_label_file ();

}; // class mn_train_t

//----------------------------------------------------------------------

} // namespace mn

//----------------------------------------------------------------------

#endif // INCLUDED_mn_label_hpp_t
