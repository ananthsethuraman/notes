//----------------------------------------------------------------------

#include <iostream>
#include "su_begin_end_t.hpp"

//----------------------------------------------------------------------

using namespace std;
using namespace su;

//----------------------------------------------------------------------

su_begin_end_t::su_begin_end_t (const char *    fn,
                                const int       line_num,
                                const string    caption)
:
caption_ (caption)
{
    cout << "STATUS:: Begin of " << caption_ << endl;
}

//----------------------------------------------------------------------

su_begin_end_t::~su_begin_end_t ()
{
    cout << "STATUS:: End of " << caption_ << endl;
}

//----------------------------------------------------------------------
