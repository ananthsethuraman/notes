//----------------------------------------------------------------------

#ifndef INCLUDED_su_begin_end_t_hpp
#define INCLUDED_su_begin_end_t_hpp

//----------------------------------------------------------------------

using namespace std;

//----------------------------------------------------------------------

namespace su
{

//----------------------------------------------------------------------

class su_begin_end_t
{

public:

    /**
        \par EXAMPLE
        Let an instance of this class be defined like so:
            \code
                su_begin_end_t begin_end (__FILE__, __LINE__,
                                          "reading input file");
            \endcode
        The constructor will print a line like so:
            \code
                STATUS:: Begin of reading input file
            \endcode
        The destructor will print a line like so:
        \code
            STATUS:: End of reading input file
        \endcode    
    */

    su_begin_end_t (const char *    fn,
                    const int       line_num,
                    const string    caption);

    ~su_begin_end_t ();

private:

    string caption_;

}; // class su_begin_t

//----------------------------------------------------------------------

} // namespace su

//----------------------------------------------------------------------

#endif // INCLUDED_su_begin_end_t_hpp

//----------------------------------------------------------------------

